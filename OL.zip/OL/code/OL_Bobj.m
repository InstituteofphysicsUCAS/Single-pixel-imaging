clear all;
close all;
clc
%% ============================B=================================
% dir = 'E:\OL\������ͼ\B\';
% name = 'Preview_2023072303_B03';
% A = fitsread([dir,name,'.fit']);
% subplot(1,2,1);
% imshow(A,[]);
% 
% [val,ind] = sort(A(:));
% 
% thre=find(val == 10980); % 27000 25000  is the background grayscale
% % max_cut=find(val == 26000);
% A(ind(1:thre(1)))=0;
% % A(ind(max_cut(1):end))=28000;
% Res_B = A./max( A(:) );
% subplot(1,2,2);
% imshow((Res_B),[]);
% 
% imwrite(Res_B,'D:\MATLAB\OL\results\Letter_B_03_Gian=100.png');
%% =============== L =======================
dir = 'E:\OL\������ͼ\L\';
name = 'Preview_2023072301_L03g100';
A = fitsread([dir,name,'.fit']);
subplot(1,2,1);
imshow(A,[]);

[val,ind] = sort(A(:));

thre=find(val == 9710); % 27000 25000  is the background grayscale
% max_cut=find(val == 26000);
A(ind(1:thre(1)))=0;
% A(ind(max_cut(1):end))=28000;
Res_B = A./max( A(:) );
subplot(1,2,2);
imshow((Res_B),[]);

imwrite(Res_B,'D:\MATLAB\OL\results\Letter_L_03_Gain=100.png');
%% =============== Z =======================
% dir = 'E:\OL\������ͼ\Z\';
% name = 'Preview_20230724_Z03';
% A = fitsread([dir,name,'.fit']);
% subplot(1,2,1);
% imshow(A,[]);
% 
% [val,ind] = sort(A(:));
% 
% thre=find(val == 6000); % 25360 28140  is the background grayscale
% % max_cut=find(val == 26000);
% A(ind(1:thre(1)))=0;
% % A(ind(max_cut(1):end))=28000;
% Res_B = A./max( A(:) );
% subplot(1,2,2);
% imshow((Res_B),[]);
% 
% imwrite(Res_B,'D:\MATLAB\OL\results\Letter_Z_03-Gain=100.png');